test = {
  'name': 'efficiency_practice',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': 'b73ec377fef76fd2d71fb08b656945a2',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The count_partitions function runs in ____ time in the length of its input.'
        },
        {
          'answer': '283f29564937de236873fd9ad423ca2b',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The is_palindrome function runs in ____ time in the length of its input.'
        },
        {
          'answer': '6cd9100091b88817235caa26caa0aa81',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The binary_search function runs in ____ time in the length of its input.'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
